#!/bin/bash
sudo yum install -y php
sudo yum install -y php-mysql
sudo yum install -y mysql
sudo service httpd restart
