#!/bin/bash
sudo service httpd start
