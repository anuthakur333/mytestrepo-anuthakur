#!/bin/bash
Version R3.1
41
AWS Managed Services User Guide
Example: Deploy a WordPress Application
chmod -R 755 /var/www/html/WordPress
cp /var/www/html/WordPress/wp-config-sample.php /var/www/html/WordPress/wp-config.php
cd /var/www/html/WordPress
sed -i "s/database_name_here/wordpress/g" wp-config.php
sed -i "s/username_here/dbadmin/g" wp-config.php
sed -i "s/password_here/p4ssw0rd/g" wp-config.php
sed -i "s/localhost/srymy7izsmixyw/g" wp-config.php
