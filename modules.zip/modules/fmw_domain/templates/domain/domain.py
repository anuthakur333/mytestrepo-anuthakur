# load common defs
execfile('<%= scope.lookupvar("fmw_domain::tmp_dir") %>/common.py')

# weblogic node params
WLHOME         = '<%= scope.lookupvar("fmw_domain::weblogic_home_dir") %>'
JAVA_HOME      = '<%= scope.lookupvar("fmw_domain::java_home_dir") %>'
BASE_TEMPLATE  = '<%= @wls_base_template %>'

# domain params
DOMAIN_PATH       = '<%= @domain_dir %>'
DOMAIN            = '<%= scope.lookupvar("fmw_domain::domain_name") %>'
WEBLOGIC_USER     = '<%= scope.lookupvar("fmw_domain::weblogic_user") %>'
WEBLOGIC_PASSWORD = '<%= scope.lookupvar("fmw_domain::weblogic_password") %>'

# adminserver params
ADMIN_SERVER_NAME              = '<%= scope.lookupvar("fmw_domain::adminserver_name") %>'
ADMIN_SERVER_STARTUP_ARGUMENTS = '<%= scope.lookupvar("fmw_domain::adminserver_startup_arguments") %>'
ADMIN_SERVER_LISTEN_ADDRESS    = '<%= scope.lookupvar("fmw_domain::adminserver_listen_address") %>'
ADMIN_SERVER_LISTEN_PORT       = <%= scope.lookupvar("fmw_domain::adminserver_listen_port") %>
#MACHINE_NAME                   = '<%= scope.lookupvar("fmw_domain::adminserver_listen_address") %>'
NODEMANAGER_LISTEN_PORT        = <%= scope.lookupvar("fmw_domain::nodemanager_port") %>
cluster_name                   = '<%= scope.lookupvar("fmw_domain::cluster_name") %>'

test=ADMIN_SERVER_LISTEN_ADDRESS.split('.')
MACHINE_NAME = test[0]


# domain configuration

machines = <%= scope.lookupvar("fmw_domain::machines") %>
ms_machines= <%= scope.lookupvar("fmw_domain::ms_machines") %>
servers = <%= scope.lookupvar("fmw_domain::managed_servers") %>
l_a_servers = <%= scope.lookupvar("fmw_domain::ms_listen_address") %>
l_p_servers = <%= scope.lookupvar("fmw_domain::ms_listen_ports") %>
arg_servers = '<%= scope.lookupvar("fmw_domain::ms_server_args") %>'

print cluster_name
print('Start normal domain... with template ' + BASE_TEMPLATE)
readTemplate(BASE_TEMPLATE)

for i in range(len(machines)):
    createMachine(machines[i],ADMIN_SERVER_LISTEN_ADDRESS,NODEMANAGER_LISTEN_PORT)
    print "ADMIN AND MS MACHINES CREATED"



print('Change the AdminServer')
changeAdminServer(ADMIN_SERVER_NAME, MACHINE_NAME, ADMIN_SERVER_LISTEN_ADDRESS,ADMIN_SERVER_LISTEN_PORT, ADMIN_SERVER_STARTUP_ARGUMENTS, JAVA_HOME)
cd('/Servers/' + ADMIN_SERVER_NAME)
ssl=create(ADMIN_SERVER_NAME,'SSL')
ssl.setEnabled(1)
ssl.setListenPort(int(ADMIN_SERVER_LISTEN_PORT+1))
print "SSL port set"
configLog(ADMIN_SERVER_NAME)

print('Set password...')
setWebLogicPassword(WEBLOGIC_USER, WEBLOGIC_PASSWORD)

setOption('JavaHome', JAVA_HOME)
setOption('ServerStartMode', 'prod')



for i in range(len(servers)):
     cd('/')
     create(servers[i], 'Server')

changeManagedServer(servers, ms_machines, l_a_servers, l_p_servers, arg_servers, JAVA_HOME)

cd('/')
create(cluster_name, 'Cluster')


for i in range(len(servers)):
     print "cluster " + cluster_name + " member " + servers[i]
     cd('/')
     assign('Server',servers[i],'Cluster',cluster_name)
     print "COMPLETED"

print('write domain...')
writeDomain(DOMAIN_PATH)
closeTemplate()
print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%123%%%%%%%%%%%%%%%%%")
#configNM(DOMAIN)
#configLdap(DOMAIN)
# create startup and boot.properties for the adminserver
createAdminStartupPropertiesFile(DOMAIN_PATH+'/servers/' + ADMIN_SERVER_NAME + '/data/nodemanager', ADMIN_SERVER_STARTUP_ARGUMENTS)
createBootPropertiesFile(DOMAIN_PATH + '/servers/' + ADMIN_SERVER_NAME + '/security', 'boot.properties', WEBLOGIC_USER, WEBLOGIC_PASSWORD)
#configNM(DOMAIN)
print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%456%%%%%%%%%%%%%%%%%")
print('Exiting...')
exit()
