#!/bin/bash 
sudo service httpd stop  
